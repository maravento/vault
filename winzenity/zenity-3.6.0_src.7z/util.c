/*
 * util.c
 *
 * Copyright (C) 2002 Sun Microsystems, Inc.
 *           (C) 1999, 2000 Red Hat Inc.
 *           (C) 1998 James Henstridge
 *           (C) 1995-2002 Free Software Foundation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 *
 * Authors: Glynn Foster <glynn.foster@sun.com>
 *          Havoc Pennington <hp@redhat.com>
 *          James Henstridge <james@daa.com.au>
 *          Tom Tromey <tromey@redhat.com>
 */

#include "config.h"
#include <windows.h>
#include <stdio.h>
#include <locale.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "config.h"
#include "util.h"
#include "zenity.h"

#ifdef GDK_WINDOWING_X11
#include <gdk/gdkx.h>
#endif

#define ZENITY_OK_DEFAULT	0
#define ZENITY_CANCEL_DEFAULT	1
#define ZENITY_ESC_DEFAULT	1
#define ZENITY_ERROR_DEFAULT	-1
#define ZENITY_EXTRA_DEFAULT	127

GtkBuilder*
zenity_util_load_ui_file (const gchar *root_widget, ...)
{
  va_list args;
  gchar *arg = NULL;
  GPtrArray *ptrarray;
  GtkBuilder *builder = gtk_builder_new ();
  GError *error = NULL;
  gchar  **objects;
  guint result = 0;
  static const gchar *zenity_ui_xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> \
<interface> \
  <!-- interface-requires gtk+ 2.6 --> \
  <object class=\"GtkAdjustment\" id=\"adjustment1\"> \
    <property name=\"upper\">100</property> \
    <property name=\"step_increment\">1</property> \
    <property name=\"page_increment\">1</property> \
  </object> \
  <object class=\"GtkTextBuffer\" id=\"textbuffer1\"/> \
  <object class=\"GtkDialog\" id=\"zenity_calendar_dialog\"> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"title\" translatable=\"yes\">Calendar selection</property> \
    <property name=\"window_position\">center</property> \
    <property name=\"type_hint\">dialog</property> \
    <signal name=\"destroy\" handler=\"gtk_main_quit\" swapped=\"no\"/> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox2\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <property name=\"spacing\">2</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"dialog-action_area2\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_calendar_cancel_button\"> \
                <property name=\"label\">gtk-cancel</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_calendar_ok_button\"> \
                <property name=\"label\">gtk-ok</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"has_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkVBox\" id=\"vbox1\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"border_width\">5</property> \
            <property name=\"spacing\">6</property> \
            <child> \
              <object class=\"GtkVBox\" id=\"vbox2\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"spacing\">6</property> \
                <child> \
                  <object class=\"GtkLabel\" id=\"zenity_calendar_text\"> \
                    <property name=\"visible\">True</property> \
                    <property name=\"can_focus\">False</property> \
                    <property name=\"xalign\">0</property> \
                    <property name=\"label\" translatable=\"yes\">Select a date from below.</property> \
                    <property name=\"wrap\">True</property> \
                  </object> \
                  <packing> \
                    <property name=\"expand\">False</property> \
                    <property name=\"fill\">False</property> \
                    <property name=\"position\">0</property> \
                  </packing> \
                </child> \
              </object> \
              <packing> \
                <property name=\"expand\">True</property> \
                <property name=\"fill\">True</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkLabel\" id=\"zenity_calendar_label\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"xalign\">0</property> \
                <property name=\"label\" translatable=\"yes\">C_alendar:</property> \
                <property name=\"use_underline\">True</property> \
                <property name=\"mnemonic_widget\">zenity_calendar</property> \
                <accessibility> \
                  <relation type=\"label-for\" target=\"zenity_calendar\"/> \
                </accessibility> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkCalendar\" id=\"zenity_calendar\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">2</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
    <action-widgets> \
      <action-widget response=\"-6\">zenity_calendar_cancel_button</action-widget> \
      <action-widget response=\"-5\">zenity_calendar_ok_button</action-widget> \
    </action-widgets> \
  </object> \
  <object class=\"GtkDialog\" id=\"zenity_entry_dialog\"> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"title\" translatable=\"yes\">Add a new entry</property> \
    <property name=\"window_position\">center</property> \
    <property name=\"type_hint\">dialog</property> \
    <signal name=\"destroy\" handler=\"gtk_main_quit\" swapped=\"no\"/> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox4\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <property name=\"spacing\">2</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"dialog-action_area4\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_entry_cancel_button\"> \
                <property name=\"label\">gtk-cancel</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_entry_ok_button\"> \
                <property name=\"label\">gtk-ok</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"has_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkVBox\" id=\"vbox3\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"border_width\">6</property> \
            <child> \
              <object class=\"GtkVBox\" id=\"vbox4\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"spacing\">6</property> \
                <child> \
                  <object class=\"GtkLabel\" id=\"zenity_entry_text\"> \
                    <property name=\"visible\">True</property> \
                    <property name=\"can_focus\">False</property> \
                    <property name=\"xalign\">0</property> \
                    <property name=\"label\" translatable=\"yes\">_Enter new text:</property> \
                    <property name=\"use_underline\">True</property> \
                  </object> \
                  <packing> \
                    <property name=\"expand\">False</property> \
                    <property name=\"fill\">False</property> \
                    <property name=\"position\">0</property> \
                  </packing> \
                </child> \
                <child> \
                  <placeholder/> \
                </child> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">True</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
    <action-widgets> \
      <action-widget response=\"-6\">zenity_entry_cancel_button</action-widget> \
      <action-widget response=\"-5\">zenity_entry_ok_button</action-widget> \
    </action-widgets> \
  </object> \
  <object class=\"GtkDialog\" id=\"zenity_error_dialog\"> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"title\" translatable=\"yes\">Error</property> \
    <property name=\"window_position\">center</property> \
    <property name=\"type_hint\">dialog</property> \
    <signal name=\"destroy\" handler=\"gtk_main_quit\" swapped=\"no\"/> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox7\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <property name=\"spacing\">14</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"dialog-action_area7\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_error_ok_button\"> \
                <property name=\"label\">gtk-ok</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkVBox\" id=\"vbox8\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"border_width\">6</property> \
            <child> \
              <object class=\"GtkHBox\" id=\"hbox3\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"border_width\">5</property> \
                <property name=\"spacing\">12</property> \
                <child> \
                  <object class=\"GtkImage\" id=\"zenity_error_image\"> \
                    <property name=\"visible\">True</property> \
                    <property name=\"can_focus\">False</property> \
                    <property name=\"yalign\">0</property> \
                    <property name=\"stock\">gtk-dialog-error</property> \
                    <property name=\"icon-size\">6</property> \
                  </object> \
                  <packing> \
                    <property name=\"expand\">True</property> \
                    <property name=\"fill\">True</property> \
                    <property name=\"position\">0</property> \
                  </packing> \
                </child> \
                <child> \
                  <object class=\"GtkLabel\" id=\"zenity_error_text\"> \
                    <property name=\"visible\">True</property> \
                    <property name=\"can_focus\">True</property> \
                    <property name=\"yalign\">0</property> \
                    <property name=\"label\" translatable=\"yes\">An error has occurred.</property> \
                    <property name=\"wrap\">True</property> \
                    <property name=\"selectable\">True</property> \
                  </object> \
                  <packing> \
                    <property name=\"expand\">False</property> \
                    <property name=\"fill\">False</property> \
                    <property name=\"position\">1</property> \
                  </packing> \
                </child> \
              </object> \
              <packing> \
                <property name=\"expand\">True</property> \
                <property name=\"fill\">True</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
    <action-widgets> \
      <action-widget response=\"-5\">zenity_error_ok_button</action-widget> \
    </action-widgets> \
  </object> \
  <object class=\"GtkDialog\" id=\"zenity_forms_dialog\"> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"type_hint\">normal</property> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox12\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <property name=\"spacing\">2</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"dialog-action_area12\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_forms_cancel_button\"> \
                <property name=\"label\">gtk-cancel</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"receives_default\">True</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_forms_ok_button\"> \
                <property name=\"label\">gtk-ok</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"receives_default\">True</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkFrame\" id=\"frame1\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"label_xalign\">0</property> \
            <child> \
              <object class=\"GtkAlignment\" id=\"alignment1\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"top_padding\">12</property> \
                <property name=\"left_padding\">12</property> \
                <property name=\"right_padding\">6</property> \
                <child> \
                  <object class=\"GtkTable\" id=\"zenity_forms_table\"> \
                    <property name=\"visible\">True</property> \
                    <property name=\"can_focus\">False</property> \
                    <property name=\"n_columns\">2</property> \
                    <property name=\"column_spacing\">10</property> \
                    <property name=\"row_spacing\">6</property> \
                    <child> \
                      <placeholder/> \
                    </child> \
                    <child> \
                      <placeholder/> \
                    </child> \
                  </object> \
                </child> \
              </object> \
            </child> \
            <child type=\"label\"> \
              <object class=\"GtkLabel\" id=\"zenity_forms_text\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"label\" translatable=\"yes\">Forms dialog</property> \
                <attributes> \
                  <attribute name=\"weight\" value=\"bold\"/> \
                </attributes> \
              </object> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
    <action-widgets> \
      <action-widget response=\"-6\">zenity_forms_cancel_button</action-widget> \
      <action-widget response=\"-5\">zenity_forms_ok_button</action-widget> \
    </action-widgets> \
  </object> \
  <object class=\"GtkDialog\" id=\"zenity_info_dialog\"> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"title\" translatable=\"yes\">Information</property> \
    <property name=\"window_position\">center</property> \
    <property name=\"type_hint\">dialog</property> \
    <signal name=\"destroy\" handler=\"gtk_main_quit\" swapped=\"no\"/> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox9\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <property name=\"spacing\">14</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"dialog-action_area3\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_info_ok_button\"> \
                <property name=\"label\">gtk-ok</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkHBox\" id=\"hbox4\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"border_width\">5</property> \
            <property name=\"spacing\">12</property> \
            <child> \
              <object class=\"GtkImage\" id=\"zenity_info_image\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"yalign\">0</property> \
                <property name=\"stock\">gtk-dialog-info</property> \
                <property name=\"icon-size\">6</property> \
              </object> \
              <packing> \
                <property name=\"expand\">True</property> \
                <property name=\"fill\">True</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkLabel\" id=\"zenity_info_text\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"yalign\">0</property> \
                <property name=\"label\" translatable=\"yes\">All updates are complete.</property> \
                <property name=\"wrap\">True</property> \
                <property name=\"selectable\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
    <action-widgets> \
      <action-widget response=\"-5\">zenity_info_ok_button</action-widget> \
    </action-widgets> \
  </object> \
  <object class=\"GtkDialog\" id=\"zenity_progress_dialog\"> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"title\" translatable=\"yes\">Progress</property> \
    <property name=\"window_position\">center</property> \
    <property name=\"type_hint\">dialog</property> \
    <signal name=\"destroy\" handler=\"gtk_main_quit\" swapped=\"no\"/> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox6\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <property name=\"spacing\">2</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"dialog-action_area6\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_progress_cancel_button\"> \
                <property name=\"label\">gtk-cancel</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_progress_ok_button\"> \
                <property name=\"label\">gtk-ok</property> \
                <property name=\"visible\">True</property> \
                <property name=\"sensitive\">False</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"has_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkVBox\" id=\"vbox7\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"border_width\">5</property> \
            <property name=\"spacing\">6</property> \
            <child> \
              <object class=\"GtkLabel\" id=\"zenity_progress_text\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"xalign\">0</property> \
                <property name=\"label\" translatable=\"yes\">Running...</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkProgressBar\" id=\"zenity_progress_bar\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"pulse_step\">0.10000000149</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
    <action-widgets> \
      <action-widget response=\"-6\">zenity_progress_cancel_button</action-widget> \
      <action-widget response=\"-5\">zenity_progress_ok_button</action-widget> \
    </action-widgets> \
  </object> \
  <object class=\"GtkDialog\" id=\"zenity_question_dialog\"> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"title\" translatable=\"yes\">Question</property> \
    <property name=\"window_position\">center</property> \
    <property name=\"type_hint\">dialog</property> \
    <signal name=\"destroy\" handler=\"gtk_main_quit\" swapped=\"no\"/> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox3\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <property name=\"spacing\">14</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"zenity_question_button_box\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkHBox\" id=\"hbox1\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"border_width\">5</property> \
            <property name=\"spacing\">12</property> \
            <child> \
              <object class=\"GtkImage\" id=\"zenity_question_image\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"xalign\">0</property> \
                <property name=\"yalign\">0</property> \
                <property name=\"stock\">gtk-dialog-question</property> \
                <property name=\"icon-size\">6</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">True</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkLabel\" id=\"zenity_question_text\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"yalign\">0</property> \
                <property name=\"label\" translatable=\"yes\">Are you sure you want to proceed?</property> \
                <property name=\"wrap\">True</property> \
                <property name=\"selectable\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
  </object> \
  <object class=\"GtkDialog\" id=\"zenity_scale_dialog\"> \
    <property name=\"visible\">True</property> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"title\" translatable=\"yes\">Adjust the scale value</property> \
    <property name=\"default_width\">300</property> \
    <property name=\"default_height\">100</property> \
    <property name=\"type_hint\">dialog</property> \
    <signal name=\"destroy\" handler=\"gtk_main_quit\" swapped=\"no\"/> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox11\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"dialog-action_area11\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_scale_cancel_button\"> \
                <property name=\"label\">gtk-cancel</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_scale_ok_button\"> \
                <property name=\"label\">gtk-ok</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkVBox\" id=\"vbox13\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"border_width\">5</property> \
            <property name=\"spacing\">6</property> \
            <child> \
              <object class=\"GtkLabel\" id=\"zenity_scale_text\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"xalign\">0</property> \
                <property name=\"ypad\">4</property> \
                <property name=\"label\" translatable=\"yes\">Adjust the scale value</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkHScale\" id=\"zenity_scale_hscale\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"adjustment\">adjustment1</property> \
                <property name=\"digits\">0</property> \
                <property name=\"value_pos\">right</property> \
              </object> \
              <packing> \
                <property name=\"expand\">True</property> \
                <property name=\"fill\">True</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
    <action-widgets> \
      <action-widget response=\"-6\">zenity_scale_cancel_button</action-widget> \
      <action-widget response=\"-5\">zenity_scale_ok_button</action-widget> \
    </action-widgets> \
  </object> \
  <object class=\"GtkDialog\" id=\"zenity_text_dialog\"> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"title\" translatable=\"yes\">Text View</property> \
    <property name=\"window_position\">center</property> \
    <property name=\"default_width\">300</property> \
    <property name=\"default_height\">200</property> \
    <property name=\"type_hint\">dialog</property> \
    <signal name=\"destroy\" handler=\"gtk_main_quit\" swapped=\"no\"/> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox5\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <property name=\"spacing\">2</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"dialog-action_area5\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_text_cancel_button\"> \
                <property name=\"label\">gtk-cancel</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_text_close_button\"> \
                <property name=\"label\">gtk-ok</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">True</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
                <property name=\"image_position\">right</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkVBox\" id=\"vbox5\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"border_width\">5</property> \
            <child> \
              <object class=\"GtkScrolledWindow\" id=\"zenity_text_scrolled_window\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"shadow_type\">etched-in</property> \
                <child> \
                  <object class=\"GtkTextView\" id=\"zenity_text_view\"> \
                    <property name=\"visible\">True</property> \
                    <property name=\"can_focus\">True</property> \
                    <property name=\"pixels_above_lines\">2</property> \
                    <property name=\"pixels_below_lines\">2</property> \
                    <property name=\"editable\">False</property> \
                    <property name=\"wrap_mode\">word</property> \
                    <property name=\"left_margin\">2</property> \
                    <property name=\"right_margin\">2</property> \
                    <property name=\"buffer\">textbuffer1</property> \
                  </object> \
                </child> \
              </object> \
              <packing> \
                <property name=\"expand\">True</property> \
                <property name=\"fill\">True</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkCheckButton\" id=\"zenity_text_checkbox\"> \
                <property name=\"can_focus\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"xalign\">0</property> \
                <property name=\"draw_indicator\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">True</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
    <action-widgets> \
      <action-widget response=\"-6\">zenity_text_cancel_button</action-widget> \
      <action-widget response=\"-7\">zenity_text_close_button</action-widget> \
    </action-widgets> \
  </object> \
  <object class=\"GtkDialog\" id=\"zenity_tree_dialog\"> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"title\" translatable=\"yes\">Select items from the list</property> \
    <property name=\"window_position\">center</property> \
    <property name=\"default_width\">300</property> \
    <property name=\"default_height\">196</property> \
    <property name=\"type_hint\">dialog</property> \
    <signal name=\"destroy\" handler=\"gtk_main_quit\" swapped=\"no\"/> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox8\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"dialog-action_area8\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_tree_cancel_button\"> \
                <property name=\"label\">gtk-cancel</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_tree_ok_button\"> \
                <property name=\"label\">gtk-ok</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkVBox\" id=\"vbox10\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"border_width\">5</property> \
            <property name=\"spacing\">6</property> \
            <child> \
              <object class=\"GtkLabel\" id=\"zenity_tree_text\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"xalign\">0</property> \
                <property name=\"label\" translatable=\"yes\">Select items from the list below.</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkScrolledWindow\" id=\"zenity_tree_window\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"shadow_type\">in</property> \
                <child> \
                  <object class=\"GtkTreeView\" id=\"zenity_tree_view\"> \
                    <property name=\"visible\">True</property> \
                    <property name=\"can_focus\">True</property> \
                    <property name=\"has_focus\">True</property> \
                    <child internal-child=\"selection\"> \
                      <object class=\"GtkTreeSelection\" id=\"treeview-selection1\"/> \
                    </child> \
                  </object> \
                </child> \
              </object> \
              <packing> \
                <property name=\"expand\">True</property> \
                <property name=\"fill\">True</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
    <action-widgets> \
      <action-widget response=\"-6\">zenity_tree_cancel_button</action-widget> \
      <action-widget response=\"-5\">zenity_tree_ok_button</action-widget> \
    </action-widgets> \
  </object> \
  <object class=\"GtkDialog\" id=\"zenity_warning_dialog\"> \
    <property name=\"can_focus\">False</property> \
    <property name=\"border_width\">5</property> \
    <property name=\"title\" translatable=\"yes\">Warning</property> \
    <property name=\"window_position\">center</property> \
    <property name=\"type_hint\">dialog</property> \
    <signal name=\"destroy\" handler=\"gtk_main_quit\" swapped=\"no\"/> \
    <child internal-child=\"vbox\"> \
      <object class=\"GtkBox\" id=\"dialog-vbox1\"> \
        <property name=\"visible\">True</property> \
        <property name=\"can_focus\">False</property> \
        <property name=\"spacing\">14</property> \
        <child internal-child=\"action_area\"> \
          <object class=\"GtkButtonBox\" id=\"dialog-action_area1\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"layout_style\">end</property> \
            <child> \
              <object class=\"GtkButton\" id=\"zenity_warning_ok_button\"> \
                <property name=\"label\">gtk-ok</property> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"has_focus\">True</property> \
                <property name=\"can_default\">True</property> \
                <property name=\"receives_default\">False</property> \
                <property name=\"use_action_appearance\">False</property> \
                <property name=\"use_stock\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"pack_type\">end</property> \
            <property name=\"position\">0</property> \
          </packing> \
        </child> \
        <child> \
          <object class=\"GtkHBox\" id=\"hbox2\"> \
            <property name=\"visible\">True</property> \
            <property name=\"can_focus\">False</property> \
            <property name=\"border_width\">5</property> \
            <property name=\"spacing\">12</property> \
            <child> \
              <object class=\"GtkImage\" id=\"zenity_warning_image\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">False</property> \
                <property name=\"xalign\">0</property> \
                <property name=\"yalign\">0</property> \
                <property name=\"stock\">gtk-dialog-warning</property> \
                <property name=\"icon-size\">6</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">True</property> \
                <property name=\"position\">0</property> \
              </packing> \
            </child> \
            <child> \
              <object class=\"GtkLabel\" id=\"zenity_warning_text\"> \
                <property name=\"visible\">True</property> \
                <property name=\"can_focus\">True</property> \
                <property name=\"yalign\">0</property> \
                <property name=\"label\" translatable=\"yes\">Are you sure you want to proceed?</property> \
                <property name=\"wrap\">True</property> \
                <property name=\"selectable\">True</property> \
              </object> \
              <packing> \
                <property name=\"expand\">False</property> \
                <property name=\"fill\">False</property> \
                <property name=\"position\">1</property> \
              </packing> \
            </child> \
          </object> \
          <packing> \
            <property name=\"expand\">False</property> \
            <property name=\"fill\">True</property> \
            <property name=\"position\">1</property> \
          </packing> \
        </child> \
      </object> \
    </child> \
    <action-widgets> \
      <action-widget response=\"-5\">zenity_warning_ok_button</action-widget> \
    </action-widgets> \
  </object> \
</interface>  ";
  static char relative_path[1024];
  static char *p;
  if (GetModuleFileNameA (NULL, relative_path, sizeof(relative_path)-1))
  {
    p = strrchr (relative_path, '\\');
    if (p)
      *p = '\0';
  }
  gchar* zenity_ui_file = g_build_filename (relative_path, "zenity.ui", NULL);
  g_free(relative_path);
  gtk_builder_set_translation_domain (builder, GETTEXT_PACKAGE);

  /* We have at least the root_widget and a NULL */
  ptrarray = g_ptr_array_sized_new (2);

  g_ptr_array_add (ptrarray, g_strdup (root_widget));

  va_start (args, root_widget);

  arg = va_arg (args, gchar*);

  while (arg) {
  	g_ptr_array_add (ptrarray, g_strdup (arg));
	arg = va_arg (args, gchar*);
  }
  va_end (args);

  /* Enforce terminating NULL */
  g_ptr_array_add (ptrarray, NULL);
  objects = (gchar**) g_ptr_array_free (ptrarray, FALSE);
  
  
  if (g_file_test (zenity_ui_file, G_FILE_TEST_EXISTS)) {
    /* Try current dir, for debugging */
    result = gtk_builder_add_objects_from_file (builder,
    						zenity_ui_file,
						objects, NULL);
  }

  if (result == 0)
    result = gtk_builder_add_objects_from_string (builder,
    						zenity_ui_xml, 
    					-1,
						objects, NULL);

  g_strfreev (objects);

  return builder;
}
gchar*
zenity_util_strip_newline (gchar *string)
{
    gsize len;
    
    g_return_val_if_fail (string != NULL, NULL);
                                                                                                                                                                             
    len = strlen (string);
    while (len--) 
    {
      if (string[len] == '\n')
        string[len] = '\0';
      else
        break;
    }
            
    return string;
}

gboolean
zenity_util_fill_file_buffer (GtkTextBuffer *buffer, const gchar *filename) 
{
  GtkTextIter iter, end;
  FILE *f;
  gchar buf[2048];
  gint remaining = 0;

  if (filename == NULL)
    return FALSE;

  f = fopen (filename, "r");

  if (f == NULL) {
    g_warning ("Cannot open file '%s': %s", filename, g_strerror (errno));
    return FALSE;
  }

  gtk_text_buffer_get_iter_at_offset (buffer, &iter, 0);

  while (!feof (f)) {
    gint count;
    const char *leftover;
    int to_read = 2047  - remaining;

    count = fread (buf + remaining, 1, to_read, f);
    buf[count + remaining] = '\0';

    g_utf8_validate (buf, count + remaining, &leftover);

    g_assert (g_utf8_validate (buf, leftover - buf, NULL));
    gtk_text_buffer_insert (buffer, &iter, buf, leftover - buf);

    remaining = (buf + remaining + count) - leftover;
    g_memmove (buf, leftover, remaining);

    if (remaining > 6 || count < to_read)
      break;
  }

  if (remaining) {
    g_warning ("Invalid UTF-8 data encountered reading file '%s'", filename);
    return FALSE;
  }

  /* We had a newline in the buffer to begin with. (The buffer always contains
   * a newline, so we delete to the end of the buffer to clean up.
   */
  
  gtk_text_buffer_get_end_iter (buffer, &end);
  gtk_text_buffer_delete (buffer, &iter, &end);

  gtk_text_buffer_set_modified (buffer, FALSE);

  return TRUE;
}

const gchar *
zenity_util_stock_from_filename (const gchar *filename)
{
  if (!filename || !filename[0])
    return GTK_STOCK_DIALOG_WARNING; /* default */

  if (!g_ascii_strcasecmp (filename, "warning"))
    return GTK_STOCK_DIALOG_WARNING;
  if (!g_ascii_strcasecmp (filename, "info"))
    return GTK_STOCK_DIALOG_INFO;
  if (!g_ascii_strcasecmp (filename, "question"))
    return GTK_STOCK_DIALOG_QUESTION;
  if (!g_ascii_strcasecmp (filename, "error"))
    return GTK_STOCK_DIALOG_ERROR;
  return NULL;
}

GdkPixbuf *
zenity_util_pixbuf_new_from_file (GtkWidget *widget, const gchar *filename)
{
  const gchar *stock;

  stock = zenity_util_stock_from_filename (filename);
  if (stock)
    return gtk_widget_render_icon (widget, stock, GTK_ICON_SIZE_BUTTON, NULL);

 return gdk_pixbuf_new_from_file (filename, NULL);
}

void
zenity_util_set_window_icon (GtkWidget *widget, const gchar *filename, const gchar *default_file)
{
  GdkPixbuf *pixbuf;

  if (filename != NULL)
    pixbuf = zenity_util_pixbuf_new_from_file (widget, (gchar *) filename);
  else
    pixbuf = gdk_pixbuf_new_from_file (default_file, NULL);  

  if (pixbuf != NULL) {
    gtk_window_set_icon (GTK_WINDOW (widget), pixbuf);
    g_object_unref (pixbuf);
  }
}

void 
zenity_util_set_window_icon_from_stock (GtkWidget *widget, const gchar *filename, const gchar *default_stock_id)
{
  GdkPixbuf *pixbuf;

  if (filename != NULL) {
    pixbuf = zenity_util_pixbuf_new_from_file (widget, (gchar *) filename);
  }
  else {
    pixbuf = gtk_widget_render_icon (widget, default_stock_id, GTK_ICON_SIZE_BUTTON, NULL);
  }

  if (pixbuf != NULL) {
    gtk_window_set_icon (GTK_WINDOW (widget), pixbuf);
    g_object_unref (pixbuf);
  }
}

void
zenity_util_show_help (GError **error)
{
  gchar *tmp;
  tmp = g_find_program_in_path ("yelp");

  if (tmp) {
    g_free (tmp);
    g_spawn_command_line_async ("yelp help:zenity", error);
  }
}

gint 
zenity_util_return_exit_code ( ZenityExitCode value ) 
{

  const gchar *env_var = NULL;
  gint retval;

  switch (value) {
  
  case ZENITY_OK:
    env_var = g_getenv("ZENITY_OK");
    if (! env_var) 
          env_var = g_getenv("DIALOG_OK");
    if (! env_var) 
          retval = ZENITY_OK_DEFAULT;
    break;
   
  case ZENITY_CANCEL:
    env_var = g_getenv("ZENITY_CANCEL");
    if (! env_var) 
          env_var = g_getenv("DIALOG_CANCEL");
    if (! env_var) 
          retval = ZENITY_CANCEL_DEFAULT;
    break;
    
  case ZENITY_ESC:
    env_var = g_getenv("ZENITY_ESC");
    if (! env_var) 
          env_var = g_getenv("DIALOG_ESC");
    if (! env_var) 
          retval = ZENITY_ESC_DEFAULT;
    break;
    
  case ZENITY_EXTRA:
    env_var = g_getenv("ZENITY_EXTRA");
    if (! env_var) 
          env_var = g_getenv("DIALOG_EXTRA");
    if (! env_var) 
          retval = ZENITY_EXTRA_DEFAULT;
    break;
    
  case ZENITY_ERROR:
    env_var = g_getenv("ZENITY_ERROR");
    if (! env_var) 
          env_var = g_getenv("DIALOG_ERROR");
    if (! env_var) 
          retval = ZENITY_ERROR_DEFAULT;
    break;
  
  case ZENITY_TIMEOUT:
    env_var = g_getenv("ZENITY_TIMEOUT");
    if (! env_var)
          env_var = g_getenv("DIALOG_TIMEOUT");
    if (! env_var)
          retval = ZENITY_TIMEOUT;
    break;
   
  default:
    retval = 1;
  }
  
  if (env_var) 
      retval = atoi (env_var);
  return retval; 
}

void
zenity_util_exit_code_with_data(ZenityExitCode value, ZenityData *zen_data)
{
  /* We assume it's being called with --timeout option and should return 5) */
  if(zen_data->timeout_delay > 0)
    zen_data->exit_code = zenity_util_return_exit_code (ZENITY_TIMEOUT);
  else
    zen_data->exit_code = zenity_util_return_exit_code (value);
}

#ifdef GDK_WINDOWING_X11

static Window
transient_get_xterm (void)
{
  const char *wid_str = g_getenv ("WINDOWID");
  if (wid_str) {
    char *wid_str_end;
    int ret;
    Window wid = strtoul (wid_str, &wid_str_end, 10);
    if (*wid_str != '\0' && *wid_str_end == '\0' && wid != 0) {
      XWindowAttributes attrs;
      gdk_error_trap_push ();
      ret = XGetWindowAttributes (GDK_DISPLAY_XDISPLAY (gdk_display_get_default ()), wid, &attrs);
      gdk_flush();
      if (gdk_error_trap_pop () != 0 || ret == 0) {
        return None;
      }
      return wid;
    }
  }
  return None;
}

static void
transient_x_free (void *ptr)
{
  if (ptr)
    XFree (ptr);
}

static gboolean
transient_is_toplevel (Window wid)
{
  XTextProperty prop;
  Display *dpy = GDK_DISPLAY_XDISPLAY (gdk_display_get_default ());
  if (!XGetWMName (dpy, wid, &prop))
    return FALSE;
  transient_x_free (prop.value);
  return !!prop.value;
}

/*
 * GNOME Terminal doesn't give us its toplevel window, but the WM needs a
 * toplevel XID for proper stacking.  Other terminals work fine without this
 * magic.  We can't use GDK here since "xterm" is a foreign window.
 */

static Window
transient_get_xterm_toplevel (void)
{
  Window xterm = transient_get_xterm ();
  Display *dpy = GDK_DISPLAY_XDISPLAY (gdk_display_get_default ());
  while (xterm != None && !transient_is_toplevel (xterm))
  {
    Window root, parent, *children;
    unsigned nchildren;
    XQueryTree (dpy, xterm,
                &root, &parent,
                &children, &nchildren);
    transient_x_free (children);
    if (parent == root)
      xterm = None;
    else
      xterm = parent;
  }
  return xterm;
}

static void
zenity_util_make_transient (GdkWindow *window)
{
  Window xterm = transient_get_xterm_toplevel ();
  if (xterm != None) {
    GdkWindow *gdkxterm = gdk_x11_window_foreign_new_for_display (gdk_display_get_default (), xterm);
    if (gdkxterm) {
      gdk_window_set_transient_for (window, gdkxterm);
      g_object_unref (G_OBJECT (gdkxterm));
    }
  }
}

#endif /* GDK_WINDOWING_X11 */

void
zenity_util_show_dialog (GtkWidget *dialog)
{
  gtk_widget_realize (dialog);
#ifdef GDK_WINDOWING_X11
  g_assert (gtk_widget_get_window(dialog));
  zenity_util_make_transient (gtk_widget_get_window(dialog));
#endif
  gtk_widget_show (dialog);
}

gboolean 
zenity_util_timeout_handle (gpointer data)
{
  GtkDialog *dialog = GTK_DIALOG(data);
  if(dialog != NULL)
    gtk_dialog_response(dialog, GTK_RESPONSE_OK);
  else {
    gtk_main_quit();
    exit(ZENITY_TIMEOUT);
  }
  return FALSE;
}
