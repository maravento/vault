# SquidAI — Base de Conocimiento Bilingüe
# Archivo fuente de verdad: intenciones, palabras clave, prompts e instrucciones.
# Formato: cada sección tiene una tabla con dos columnas: Español | Inglés

---

## INTENCIÓN: perfil_usuario | INTENT: user_profile

| Español | English |
|---------|---------|
| Consulta sobre la actividad de navegación de un usuario específico de la red. | Query about the browsing activity of a specific network user. |

### Palabras clave | Keywords

| Español | English |
|---------|---------|
| usuario | user |
| actividad | activity |
| resumen | summary |
| perfil | profile |
| tráfico | traffic |
| reporte | report |
| qué hizo | what did |
| que hizo | what did |
| navegación | browsing |
| qué visita | what visits |
| que visita | what visits |

### Patrones de nombre de usuario | Username patterns

| Español | English |
|---------|---------|
| G- = Área de gestión o gerencia | G- = Management or administration area |
| S- = Área de servicios | S- = Services area |
| D- = Dependencia o departamento | D- = Department or dependency |
| INSP- = Inspectoría | INSP- = Inspectorate |

### Acción del sistema | System action

| Español | English |
|---------|---------|
| Consultar get_user_report en worker.php con la IP del usuario y la fecha seleccionada. Devuelve top 10 dominios con consumo. Cruzar con check_blacklist para verificar lista negra. | Call get_user_report in worker.php with user IP and selected date. Returns top 10 domains with usage. Cross-check with check_blacklist for blocklist verification. |

---

## INTENCIÓN: red_global | INTENT: network_global

| Español | English |
|---------|---------|
| Consulta sobre métricas agregadas de toda la red, sin enfocarse en un usuario específico. | Query about aggregated metrics of the entire network, without focusing on a specific user. |

### Palabras clave | Keywords

| Español | English |
|---------|---------|
| dominios más visitados | most visited domains |
| top dominios | top domains |
| top 10 dominios | top 10 domains |
| más visitados hoy | most visited today |
| ancho de banda | bandwidth |
| consumo de red | network usage |
| consumo global | global consumption |
| quién consume más | who consumes the most |
| top consumidores | top consumers |
| ranking de usuarios | user ranking |
| resumen de red | network summary |
| vista general | overview |
| cuánto consume | how much consumption |

### Acción del sistema | System action

| Español | English |
|---------|---------|
| Consultar get_network_summary en worker.php que devuelve: total de bytes, hits, IPs únicas, top 10 usuarios por consumo, top 10 dominios por consumo. | Call get_network_summary in worker.php which returns: total bytes, hits, unique IPs, top 10 users by consumption, top 10 domains by consumption. |

### Instrucciones para responder | Response instructions

| Español | English |
|---------|---------|
| Si el usuario pregunta por un umbral específico (ej: "más de 3 GB", "supera 5 GB"), filtra los datos reales del JSON usando el valor numérico de bytes. | If the user asks for a specific threshold (e.g., "more than 3 GB", "exceeds 5 GB"), filter the actual JSON data using the numeric byte value. |
| NO uses los umbrales genéricos de la sección "INTERPRETACIÓN DE CONSUMO" para estas preguntas. | DO NOT use the generic thresholds from the "CONSUMPTION INTERPRETATION" section for these questions. |
| Responde SOLO con los usuarios/dominios que superen el umbral solicitado. | Respond ONLY with users/domains that exceed the requested threshold. |

---

## INTENCIÓN: umbral_consumo | INTENT: consumption_threshold

| Español | English |
|---------|---------|
| Consulta sobre usuarios que superan un límite específico de descarga. | Query about users exceeding a specific download limit. |

### Palabras clave | Keywords

| Español | English |
|---------|---------|
| sobrepasó el límite | exceeded the limit |
| superó el límite | surpassed the limit |
| excedió el límite | went over the limit |
| más de X GB | more than X GB |
| mayor a X GB | greater than X GB |
| supera los X GB | exceeds X GB |
| límite de descargas | download limit |
| usuarios que superan | users exceeding |
| descargaron más de | downloaded more than |

### Acción del sistema | System action

| Español | English |
|---------|---------|
| NO llamar a Gemini. Consultar get_network_summary y filtrar top_users por el umbral especificado. Mostrar solo los usuarios que superan el límite. | DO NOT call Gemini. Call get_network_summary and filter top_users by the specified threshold. Show only users exceeding the limit. |

---

## INTENCIÓN: accesos_bloqueados | INTENT: blocked_access

| Español | English |
|---------|---------|
| Consulta sobre qué usuarios intentaron acceder a dominios en la lista negra (blockdomains.txt). Tono informativo de política institucional, NO de alerta de seguridad. | Query about which users attempted to access domains on the blocklist (blockdomains.txt). Informative tone about institutional policy, NOT a security alert. |

### Palabras clave | Keywords

| Español | English |
|---------|---------|
| bloqueado | blocked |
| bloqueados | blocked |
| lista negra | blacklist |
| accedieron a dominios bloqueados | accessed blocked domains |
| sitios bloqueados | blocked sites |
| quién intentó acceder | who tried to access |
| qué IPs accedieron | which IPs accessed |
| política de navegación | browsing policy |
| violación de política | policy violation |

### Acción del sistema | System action

| Español | English |
|---------|---------|
| Consultar get_blocked_domains en worker.php. Muestra tabla con IP, nombre, dominio, hits. No pasa por Gemini — se renderiza directamente. | Call get_blocked_domains in worker.php. Display table with IP, name, domain, hits. Does NOT go through Gemini — rendered directly. |

---

## INTENCIÓN: security_incidents | INTENT: security_incidents

| Español | English |
|---------|---------|
| Consulta sobre incidentes de seguridad reales detectados por el proxy. Un incidente de seguridad es distinto de una violación de política: es un comportamiento de red que puede comprometer la integridad del sistema. | Query about real security incidents detected by the proxy. A security incident is different from a policy violation: it is network behavior that could compromise system integrity. |

### Diferencia clave | Key difference

| Español | English |
|---------|---------|
| Incidente de seguridad → comportamiento sospechoso (cómo se comunica el equipo) | Security incident → suspicious behavior (how the device communicates) |
| Violación de política → destino no permitido (a dónde fue el usuario) | Policy violation → disallowed destination (where the user went) |

### Palabras clave | Keywords

| Español | English |
|---------|---------|
| incidente | incident |
| incidentes | incidents |
| sospechoso | suspicious |
| amenaza | threat |
| malware | malware |
| ataque | attack |
| intrusión | intrusion |
| hay algo raro | something is wrong |
| comportamiento extraño | strange behavior |
| torrent | torrent |
| bittorrent | bittorrent |
| ip directa | direct ip |
| ips directas | direct ips |
| jndi | jndi |
| inyección | injection |
| onion | onion |
| patrones bloqueados | blocked patterns |

### Tipos de incidente detectables | Detectable incident types

| Español | English |
|---------|---------|
| IPv4 directa → equipo evitando DNS, típico de malware o P2P | Direct IPv4 → device bypassing DNS, typical of malware or P2P |
| tracker, info_hash, magnet, peer_id → tráfico BitTorrent/P2P | tracker, info_hash, magnet, peer_id → BitTorrent/P2P traffic |
| jndi: → intento de Log4Shell u otras inyecciones (CRITICAL siempre) | jndi: → Log4Shell or other injection attempt (always CRITICAL) |
| .onion → comunicación con dark web (CRITICAL siempre) | .onion → dark web communication (always CRITICAL) |

### Acción del sistema | System action

| Español | English |
|---------|---------|
| Consultar get_blocked_patterns en worker.php. Se renderiza directamente sin LLM. Muestra tabla con IP, nombre, patrón, hits y severidad calculada en el cliente. | Call get_blocked_patterns in worker.php. Rendered directly without LLM. Shows table with IP, name, pattern, hits, and severity calculated client-side. |

---

## INTENCIÓN: tlds_bloqueados | INTENT: blocked_tlds

| Español | English |
|---------|---------|
| Consulta sobre accesos a dominios con TLD bloqueados institucionalmente (blocktlds.txt). | Query about accesses to domains with institutionally blocked TLDs (blocktlds.txt). |

### Palabras clave | Keywords

| Español | English |
|---------|---------|
| tld bloqueado | blocked tld |
| tlds bloqueados | blocked tlds |
| extensión bloqueada | blocked extension |
| .tk, .xyz, .top, .click, .ru, .cn | .tk, .xyz, .top, .click, .ru, .cn |

### Acción del sistema | System action

| Español | English |
|---------|---------|
| Consultar get_blocked_tlds en worker.php. Muestra tabla con IP, nombre, dominio, TLD bloqueado, hits. No pasa por Gemini — se renderiza directamente. | Call get_blocked_tlds in worker.php. Shows table with IP, name, domain, blocked TLD, hits. Does NOT go through Gemini — rendered directly. |

---

## INTENCIÓN: listar_usuarios | INTENT: list_users

| Español | English |
|---------|---------|
| El administrador quiere ver la lista completa de usuarios registrados en el sistema. | The administrator wants to see the complete list of registered users in the system. |

### Palabras clave | Keywords

| Español | English |
|---------|---------|
| lista de usuarios | user list |
| listar usuarios | list users |
| todos los usuarios | all users |
| mostrar usuarios | show users |
| qué usuarios hay | what users exist |
| usuarios registrados | registered users |
| ver usuarios | view users |
| quiénes están registrados | who is registered |

### Acción del sistema | System action

| Español | English |
|---------|---------|
| Consultar get_users en worker.php y mostrar la tabla directamente sin llamar a Gemini. | Call get_users in worker.php and display the table directly without calling Gemini. |

---

## FORMATO DE LOGS SQUID | SQUID LOGS FORMAT

| Español | English |
|---------|---------|
| El archivo access.log tiene este formato por línea: timestamp elapsed client_ip action/http_code bytes method URL user hierarchy/peer content_type | The access.log file has this format per line: timestamp elapsed client_ip action/http_code bytes method URL user hierarchy/peer content_type |

### Códigos de acción relevantes | Relevant action codes

| Español | English |
|---------|---------|
| TCP_MISS = Petición fue al servidor de origen (cache miss) | TCP_MISS = Request went to origin server (cache miss) |
| TCP_HIT = Servida desde cache local de Squid | TCP_HIT = Served from local Squid cache |
| TCP_DENIED = Bloqueada por ACL — este es el que genera incidentes | TCP_DENIED = Blocked by ACL — this generates incidents |
| CONNECT = Túnel HTTPS — el URL solo muestra host:puerto | CONNECT = HTTPS tunnel — URL only shows host:port |

---

## ESTRUCTURA DE LIGHTSQUID | LIGHTSQUID STRUCTURE

| Español | English |
|---------|---------|
| Los reportes se almacenan en /var/www/proxymon/lightsquid/report/ con estructura: YYYYMMDD/IP_DEL_USUARIO/ | Reports are stored in /var/www/proxymon/lightsquid/report/ with structure: YYYYMMDD/USER_IP/ |
| Dentro de cada carpeta de IP hay archivos de texto, uno por dominio visitado. Formato: dominio bytes hits | Inside each IP folder there are text files, one per visited domain. Format: domain bytes hits |

---

## USUARIOS DEL SISTEMA | SYSTEM USERS

| Español | English |
|---------|---------|
| El archivo realname.cfg mapea IP a nombre de área. Formato: IP NOMBRE | The realname.cfg file maps IP to area name. Format: IP NAME |
| El archivo skipuser.cfg contiene IPs a excluir (impresoras, APs, servidores) | The skipuser.cfg file contains IPs to exclude (printers, APs, servers) |
| Los usuarios representan áreas o dependencias, no personas individuales | Users represent areas or departments, not individual people |

---

## INTERPRETACIÓN DE CONSUMO | CONSUMPTION INTERPRETATION

| Español | English |
|---------|---------|
| Consumo diario considerado normal según tipo de área | Daily consumption considered normal by area type |

| Tipo de área | Consumo normal | Alerta | Area type | Normal consumption | Alert |
|--------------|----------------|--------|-----------|-------------------|-------|
| Administrativa | menos de 500 MB | supera 2 GB | Administrative | less than 500 MB | exceeds 2 GB |
| Técnica | menos de 2 GB | supera 5 GB | Technical | less than 2 GB | exceeds 5 GB |
| Servidores | menos de 100 MB | supera 1 GB | Servers | less than 100 MB | exceeds 1 GB |

| Español | English |
|---------|---------|
| Los bytes en los logs de Squid incluyen cabeceras HTTP y cuerpo, tanto de request como de response. | Bytes in Squid logs include HTTP headers and body, both request and response. |
| Videos en streaming generan múltiples peticiones por segmento lo que multiplica el conteo de hits. | Streaming videos generate multiple requests per segment which multiplies hit count. |

---

## SEVERIDAD DE INCIDENTES | INCIDENT SEVERITY

| Español | English |
|---------|---------|
| Clasificación aplicada a incidentes de seguridad (patrones bloqueados e IPs directas) | Classification applied to security incidents (blocked patterns and direct IPs) |

| Condición | Severidad | Condition | Severity |
|-----------|-----------|-----------|----------|
| jndi: o .onion | CRITICAL | jndi: or .onion | CRITICAL |
| 20 o más hits | CRITICAL | 20 or more hits | CRITICAL |
| 5 a 19 hits | HIGH | 5 to 19 hits | HIGH |
| 1 a 4 hits | MEDIUM | 1 to 4 hits | MEDIUM |

| Español | English |
|---------|---------|
| Nota: esta clasificación aplica SOLO a security_incidents (get_blocked_patterns). Para violaciones de política (dominios, TLDs) no se usa severidad. | Note: this classification applies ONLY to security_incidents (get_blocked_patterns). Severity is NOT used for policy violations (domains, TLDs). |

---

## INSTRUCCIONES DE FORMATO PARA LLM | FORMATTING INSTRUCTIONS FOR LLM

| Español | English |
|---------|---------|
| Cuando respondas consultas de esta herramienta, sigue estas reglas | When responding to queries from this tool, follow these rules |
| Usa tablas Markdown para datos tabulares (top 10, rankings, incidentes) | Use Markdown tables for tabular data (top 10, rankings, incidents) |
| Marca alertas con el prefijo exacto: ⚠️ ALERTA: | Mark alerts with the exact prefix: ⚠️ ALERT: |
| Marca estado limpio con: ✅ | Mark clean status with: ✅ |
| Cantidades de datos en MB o GB con 2 decimales | Data amounts in MB or GB with 2 decimal places |
| Responde en el mismo idioma que el usuario usó en su consulta | Respond in the same language the user used in their query |
| No incluyas palabrería innecesaria ni saludos | Do not include unnecessary filler words or greetings |
| Cuando haya hits en lista negra incluye siempre: IP, nombre, dominio, hits | When there are blocklist hits always include: IP, name, domain, hits |

---

## GLOSARIO | GLOSSARY

| Español | English |
|---------|---------|
| Squid | Squid |
| servidor proxy caché de código abierto | open source caching proxy server |
| LightSquid | LightSquid |
| analizador de reportes para logs de Squid | report analyzer for Squid logs |
| ACL | ACL |
| Access Control List | Access Control List |
| TCP_DENIED | TCP_DENIED |
| respuesta de Squid cuando bloquea una petición por ACL | Squid response when blocking a request due to ACL |
| BM25 | BM25 |
| algoritmo de ranking de relevancia para búsqueda léxica | relevance ranking algorithm for lexical search |
| realname.cfg | realname.cfg |
| archivo de mapeo IP a nombre de usuario en LightSquid | IP to username mapping file in LightSquid |
| skipuser.cfg | skipuser.cfg |
| archivo con IPs a excluir de reportes | file with IPs to exclude from reports |
| blockdomains.txt | blockdomains.txt |
| lista negra de dominios bloqueados por política | blocklist of domains blocked by policy |
