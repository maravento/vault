<?php
/**
 * SquidAI Worker — Backend PHP
 * Lee fuentes locales del proxy y devuelve JSON al frontend
 * Soporta cualquier LLM vía API key configurable
 *
 * Rutas configurables:
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-store');

// Usar la zona horaria configurada en el sistema
$sysTz = trim(shell_exec('cat /etc/timezone 2>/dev/null || timedatectl show --property=Timezone --value 2>/dev/null') ?? '');
if ($sysTz && @timezone_open($sysTz)) {
    date_default_timezone_set($sysTz);
}

// ── IDIOMA ─────────────────────────────────────────────────────────
$lang = $_GET['lang'] ?? $_POST['lang'] ?? 'en';
$lang = ($lang === 'es') ? 'es' : 'en';

$i18n = [
    'en' => [
        'dataset_not_found' => 'dataset.md not found',
        'api_key_missing' => 'API key not configured in .env',
        'connection_error' => 'Connection error: ',
        'realname_not_found' => 'realname.cfg not found',
        'lightsquid_dir_missing' => 'LightSquid directory not found',
        'no_report' => 'No LightSquid report for this date/IP',
        'blockdomains_not_found' => 'blockdomains.txt not found',
        'cannot_read_log' => 'Cannot read access.log',
        'unknown' => 'Unknown',
    ],
    'es' => [
        'dataset_not_found' => 'dataset.md no encontrado',
        'api_key_missing' => 'API key no configurada en .env',
        'connection_error' => 'Error conectando: ',
        'realname_not_found' => 'realname.cfg no encontrado',
        'lightsquid_dir_missing' => 'Directorio LightSquid no encontrado',
        'no_report' => 'Sin reporte LightSquid para esta fecha/IP',
        'blockdomains_not_found' => 'blockdomains.txt no encontrado',
        'cannot_read_log' => 'No se pudo leer access.log',
        'unknown' => 'Desconocido',
    ]
];

function msg($key, $fallback = null) {
    global $i18n, $lang;
    return $i18n[$lang][$key] ?? $i18n['en'][$key] ?? $fallback ?? $key;
}
// ───────────────────────────────────────────────────────────────────


// ── CONFIGURACIÓN DE RUTAS ──────────────────────────────────────────
define('REALNAME_CFG',    '/var/www/proxymon/lightsquid/realname.cfg');
define('SKIPUSERS_CFG',   '/var/www/proxymon/lightsquid/skipuser.cfg');
define('LIGHTSQUID_DIR',  '/var/www/proxymon/lightsquid/report');
define('BLOCKDOMAINS',    '/etc/acl/blockdomains.txt');
define('BLOCKTLDS',       '/etc/acl/blocktlds.txt');
define('BLOCKPATTERNS',   '/etc/acl/blockpatterns.txt');
define('SQUID_LOG_DIR',   '/var/log/squid');
define('SQUID_LOG_FILE',  '/var/log/squid/access.log');
// ───────────────────────────────────────────────────────────────────

// ── API KEY DESDE .env ─────────────────────────────────────────────
function loadEnv(): void {
    $envFile = __DIR__ . '/.env';
    if (!file_exists($envFile)) return;
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;
        if (str_contains($line, '=')) {
            [$key, $val] = explode('=', $line, 2);
            $_ENV[trim($key)] = trim($val);
        }
    }
}
loadEnv();
// ──────────────────────────────────────────────────────────────────

$action = $_GET['action'] ?? 'ping';


try {
    switch ($action) {
        case 'ping':
            echo json_encode(['status' => 'ok', 'version' => '1.0', 'time' => date('c')]);
            break;

        case 'get_dataset':
            $datasetPath = __DIR__ . '/dataset.md';
            if (!file_exists($datasetPath)) {
                http_response_code(404);
                echo json_encode(['error' => msg('dataset_not_found')]);
            } else {
                echo json_encode(['content' => file_get_contents($datasetPath)]);
            }
            break;

        case 'get_users':
            echo json_encode(getUsers());
            break;

        case 'get_available_dates':
            $ip = $_GET['ip'] ?? '';
            echo json_encode(getAvailableDates($ip));
            break;

        case 'get_user_report':
            $ip   = basename(trim($_GET['ip'] ?? ''));
            if (!preg_match('/^\d{1,3}(\.\d{1,3}){3}$/', $ip)) {
                echo json_encode(['error' => 'Invalid IP']); break;
            }
            $date = $_GET['date'] ?? 'today';
            echo json_encode(getUserReport($ip, $date));
            break;

        case 'check_blacklist':
            $ip   = basename(trim($_GET['ip'] ?? ''));
            if (!preg_match('/^\d{1,3}(\.\d{1,3}){3}$/', $ip)) {
                echo json_encode(['error' => 'Invalid IP']); break;
            }
            $date = $_GET['date'] ?? 'today';
            echo json_encode(checkBlacklist($ip, $date));
            break;

        case 'get_blocked_domains':
            echo json_encode(getBlockedByType('domains'));
            break;

        case 'get_blocked_patterns':
            echo json_encode(getBlockedByType('patterns'));
            break;

        case 'get_blocked_tlds':
            echo json_encode(getBlockedByType('tlds'));
            break;

        case 'get_security_incidents': // compatibilidad hacia atrás
            echo json_encode(getBlockedByType('domains'));
            break;

        case 'get_network_summary':
            $date = $_GET['date'] ?? 'today';
            echo json_encode(getNetworkSummary($date));
            break;

        case 'get_report_dates':
            // Lista todas las fechas disponibles en LightSquid (reporte global)
            $dirs  = is_dir(LIGHTSQUID_DIR) ? glob(LIGHTSQUID_DIR . '/[0-9]*', GLOB_ONLYDIR) : [];
            rsort($dirs);
            $dates = [];
            foreach ($dirs as $d) {
                $raw = basename($d);
                if (preg_match('/^(\d{4})(\d{2})(\d{2})$/', $raw, $m)) {
                    $dates[] = ['folder' => $raw, 'label' => $m[1] . '-' . $m[2] . '-' . $m[3]];
                }
            }
            echo json_encode(['dates' => $dates]);
            break;
        
        case 'get_api_status':
            $key = $_ENV['API_KEY'] ?? '';
            echo json_encode(['configured' => $key !== '']);
            break;

        case 'llm_proxy':
            $key = $_ENV['API_KEY'] ?? '';
            if (!$key) {
                http_response_code(503);
                echo json_encode(['error' => msg('api_key_missing')]);
                break;
            }
            $template = $_ENV['LLM_URL'] ?? '';
            $url      = str_replace('{key}', $key, $template);
            $payload  = file_get_contents('php://input');
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            $resp = curl_exec($ch);
            $curlError = curl_error($ch);
            curl_close($ch);
            if ($resp === false) {
                http_response_code(502);
                echo json_encode(['error' => msg('connection_error') . $curlError]);
                break;
            }
            echo $resp;
            break;

        default:
            http_response_code(400);
            echo json_encode(['error' => 'Unknown action: ' . $action]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

// ── FUNCIONES ──────────────────────────────────────────────────────

/**
 * Lee realname.cfg y devuelve lista de usuarios
 * Formato: 192.168.10.73 S-SIVIGILA
 */
function getUsers(): array {
    if (!file_exists(REALNAME_CFG)) {
        return ['error' => msg('realname_not_found'), 'users' => []];
    }

    // Cargar IPs a excluir desde skipuser.cfg
    $skipIps = [];
    $skipFile = SKIPUSERS_CFG;
    if (file_exists($skipFile)) {
        $skipLines = file($skipFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($skipLines as $sl) {
            $sl = trim($sl);
            if ($sl && $sl[0] !== '#') {
                $slParts = preg_split('/\s+/', $sl, 2);
                $skipIps[] = $slParts[0]; // solo la IP
            }
        }
    }

    $users = [];
    $lines = file(REALNAME_CFG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;
        $parts = preg_split('/\s+/', $line, 2);
        if (count($parts) === 2) {
            $ip = $parts[0];
            if (in_array($ip, $skipIps)) continue; // excluir impresoras, APs, etc.
            $users[] = ['ip' => $ip, 'name' => $parts[1]];
        }
    }

    return ['users' => $users, 'count' => count($users)];
}

/**
 * Lista fechas disponibles en LightSquid para una IP
 * Estructura: /reports/YYYYMMDD/IP/
 */
function getAvailableDates(string $ip): array {
    if (!$ip) return ['dates' => []];

    // Sanitizar y validar IP
    $ip = basename(trim($ip));
    
    // Validar formato de IP válida (IPv4)
    if (!preg_match('/^\d{1,3}(\.\d{1,3}){3}$/', $ip)) {
        return ['dates' => [], 'error' => 'Invalid IP format'];
    }
    
    // Validar que cada octeto esté entre 0 y 255
    $octets = explode('.', $ip);
    foreach ($octets as $octet) {
        if ((int)$octet < 0 || (int)$octet > 255) {
            return ['dates' => [], 'error' => 'Invalid IP range'];
        }
    }

    $dates = [];
    $dir   = LIGHTSQUID_DIR;
    $currentYear = date('Y');

    if (!is_dir($dir)) {
        return ['dates' => [], 'note' => msg('lightsquid_dir_missing')];
    }

    $dateDirs = glob($dir . '/[0-9]*', GLOB_ONLYDIR);
    if (!$dateDirs) return ['dates' => []];

    rsort($dateDirs);

    foreach ($dateDirs as $dateDir) {
        $dateStr = basename($dateDir);

        if (!preg_match('/^(\d{4})(\d{2})(\d{2})$/', $dateStr, $m)) continue;
        if ($m[1] !== $currentYear) continue;

        $ipFile = $dateDir . '/' . $ip;

        if (!file_exists($ipFile)) continue;

        $dates[] = $m[1] . '-' . $m[2] . '-' . $m[3];
    }

    return ['dates' => $dates, 'ip' => $ip];
}

/**
 * Obtiene reporte de tráfico de un usuario por IP y fecha
 */
function getUserReport(string $ip, string $date): array {
    if (!$ip) return ['error' => 'IP required'];

    $result = [
        'ip'      => $ip,
        'date'    => $date,
        'domains' => [],
        'total_bytes' => 0,
        'source'  => 'unknown',
    ];

    // Intentar LightSquid primero
    $lightsquidResult = readLightSquidReport($ip, $date);
    if (!empty($lightsquidResult['domains'])) {
        return array_merge($result, $lightsquidResult, ['source' => 'lightsquid']);
    }

    // Fallback: parsear access.log
    $logResult = parseAccessLog($ip, $date);
    return array_merge($result, $logResult, ['source' => 'access.log']);
}

/**
 * Lee reportes de LightSquid para una IP/fecha
 * LightSquid guarda archivos por IP dentro de carpetas por fecha
 */
function readLightSquidReport(string $ip, string $date): array {
    $dateFormatted = str_replace('-', '', $date); // YYYYMMDD
    $reportFile    = LIGHTSQUID_DIR . '/' . $dateFormatted . '/' . $ip;

    if (!is_file($reportFile)) {
        return ['domains' => [], 'note' => msg('no_report')];
    }

    $domains    = [];
    $totalBytes = 0;

    $lines = file($reportFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if (!$line || str_starts_with($line, '#')) continue;

        // Línea total: "total: NNNN"
        if (str_starts_with($line, 'total:')) {
            $totalBytes = (int)trim(substr($line, 6));
            continue;
        }

        // Formato: dominio bytes hits columnas_hora...
        $parts = preg_split('/\s+/', $line, 4);
        if (count($parts) < 2) continue;

        $domain = $parts[0];
        $bytes  = (int)$parts[1];
        $hits   = isset($parts[2]) ? (int)$parts[2] : 1;

        if (isset($domains[$domain])) {
            $domains[$domain]['bytes'] += $bytes;
            $domains[$domain]['hits']  += $hits;
        } else {
            $domains[$domain] = ['domain' => $domain, 'bytes' => $bytes, 'hits' => $hits];
        }
    }

    usort($domains, fn($a, $b) => $b['bytes'] - $a['bytes']);
    $top10 = array_slice(array_values($domains), 0, 10);
    foreach ($top10 as &$d) $d['bytes_human'] = formatBytes($d['bytes']);

    return [
        'domains'      => $top10,
        'total_bytes'  => $totalBytes,
        'total_human'  => formatBytes($totalBytes),
        'domain_count' => count($domains),
    ];
}

/**
 * Parsea access.log de Squid filtrando por IP y fecha
 * Formato: timestamp elapsed client action/code bytes method url ...
 */
function parseAccessLog(string $ip, string $date): array {
    $domains    = [];
    $totalBytes = 0;

    // Determinar rango de timestamps
    $targetDate = ($date === 'today') ? date('Y-m-d') : $date;
    $startTs    = strtotime($targetDate . ' 00:00:00');
    $endTs      = $startTs + 86400;

    // Logs posibles: access.log, access.log.1, etc.
    $logFiles = [SQUID_LOG_FILE];
    $rotated  = glob(SQUID_LOG_DIR . '/access.log.*');
    if ($rotated) $logFiles = array_merge($logFiles, $rotated);

    foreach ($logFiles as $logFile) {
        if (!file_exists($logFile)) continue;

        $fh = @fopen($logFile, 'r');
        if (!$fh) continue;

        // Para archivos grandes, leer en chunks
        $lineCount = 0;
        while (($line = fgets($fh)) !== false) {
            $lineCount++;
            if ($lineCount > 2000000) break; // límite de seguridad

            $line = trim($line);
            if (!$line) continue;

            // Formato Squid: "1234567890.123   1234 192.168.1.1 TCP_MISS/200 12345 GET http://domain/path ..."
            $parts = preg_split('/\s+/', $line);
            if (count($parts) < 7) continue;

            $ts      = (float)$parts[0];
            $clientIp = $parts[2];
            $bytes    = (int)$parts[4];
            $url      = $parts[6] ?? '';

            // Filtrar por IP y fecha
            if ($clientIp !== $ip) continue;
            if ($ts < $startTs || $ts >= $endTs) {
                // Optimización: si ya pasamos la fecha, salir
                if ($ts >= $endTs && count($domains) > 0) break;
                continue;
            }

            // Extraer dominio
            $domain = extractDomain($url);
            if (!$domain) continue;

            if (isset($domains[$domain])) {
                $domains[$domain]['bytes'] += $bytes;
                $domains[$domain]['hits']++;
            } else {
                $domains[$domain] = ['domain' => $domain, 'bytes' => $bytes, 'hits' => 1];
            }
            $totalBytes += $bytes;
        }
        fclose($fh);
    }

    usort($domains, fn($a, $b) => $b['bytes'] - $a['bytes']);
    $top10 = array_slice(array_values($domains), 0, 10);
    foreach ($top10 as &$d) {
        $d['bytes_human'] = formatBytes($d['bytes']);
    }

    return [
        'domains'      => $top10,
        'total_bytes'  => $totalBytes,
        'total_human'  => formatBytes($totalBytes),
        'domain_count' => count($domains),
    ];
}

/**
 * Verifica accesos a dominios en lista negra para una IP/fecha
 */
function checkBlacklist(string $ip, string $date): array {
    if (!file_exists(BLOCKDOMAINS)) {
        return ['error' => msg('blockdomains_not_found'), 'hits' => []];
    }

    // Cargar lista negra
    $blacklist = [];
    $lines = file(BLOCKDOMAINS, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line && $line[0] !== '#') {
            $blacklist[] = strtolower($line);
        }
    }

    if (empty($blacklist)) return ['hits' => [], 'blacklist_count' => 0];

    // Obtener dominios visitados
    $report = getUserReport($ip, $date);
    $hits   = [];

    foreach ($report['domains'] as $domainData) {
        $domain = strtolower($domainData['domain']);
        foreach ($blacklist as $blocked) {
            if ($domain === $blocked || str_ends_with($domain, '.' . $blocked)) {
                $hits[] = [
                    'domain'      => $domainData['domain'],
                    'blocked_as'  => $blocked,
                    'bytes'       => $domainData['bytes'],
                    'bytes_human' => formatBytes($domainData['bytes']),
                    'hits'        => $domainData['hits'],
                    'severity'    => 'HIGH',
                ];
                break;
            }
        }
    }

    return [
        'hits'            => $hits,
        'hit_count'       => count($hits),
        'blacklist_count' => count($blacklist),
        'ip'              => $ip,
        'date'            => $date,
        'clean'           => empty($hits),
    ];
}

/**
 * Lee TCP_DENIED del access.log y filtra según el tipo:
 * - 'domains'  → dominio en blockdomains.txt
 * - 'patterns' → dominio coincide con regex de patrones bloqueados
 * - 'tlds'     → TLD del dominio en blocktlds.txt
 */
function getBlockedByType(string $type): array {

    $usersData = getUsers();
    $userMap   = [];
    foreach ($usersData['users'] ?? [] as $u) {
        $userMap[$u['ip']] = $u['name'];
    }

    $incidentMap = [];
    $totalBytes  = 0;

    // 🔹 Cargar patrones REALES
    $patterns = [];

    // PATRONES
    if ($type === 'patterns') {
        // IPv4 directa SIEMPRE
        $patterns[] = ['/^(https?:\/\/)?[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/', 'IPv4 directa'];

        if (file_exists(BLOCKPATTERNS)) {
            foreach (file(BLOCKPATTERNS, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#') continue;

                $patterns[] = ['/' . preg_quote($line, '/') . '/i', $line];
            }
        }
    }
    
    // 🔹 Cargar dominios bloqueados
    $blockedDomains = [];
    if ($type === 'domains' && file_exists(BLOCKDOMAINS)) {
        foreach (file(BLOCKDOMAINS, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $line = trim($line);
            if ($line && $line[0] !== '#') {
                $blockedDomains[] = strtolower($line);
            }
        }
    }

    $logFile = escapeshellarg(SQUID_LOG_FILE);
    $handle  = popen("grep -a 'TCP_DENIED' {$logFile}", 'r');
    if (!$handle) return ['error' => msg('cannot_read_log'), 'incidents' => []];

    $hoy = date('Y-m-d');

    while (($line = fgets($handle)) !== false) {

        $parts = preg_split('/\s+/', trim($line));
        if (count($parts) < 7) continue;

        $ts = (float)$parts[0];
        if (date('Y-m-d', (int)$ts) !== $hoy) continue;

        $client = $parts[2];
        $bytes  = (int)$parts[4];
        $url    = $parts[6] ?? '';

        $domain = strtolower(extractDomain($url));
        if (!$domain) $domain = $url;

        // 🔴 FILTRO REAL POR PATRONES
        if ($type === 'patterns') {
            $matched = null;

            foreach ($patterns as [$regex, $label]) {
                if (@preg_match($regex, $url)) {
                    $matched = $label;
                    break;
                }
            }

            if ($matched === null) continue;

            $key = $client . '|' . $matched;

            if (!isset($incidentMap[$key])) {
                $incidentMap[$key] = [
                    'ip'      => $client,
                    'name'    => $userMap[$client] ?? msg('unknown'),
                    'pattern' => $matched,
                    'hits'    => 0,
                ];
            }

            $incidentMap[$key]['hits']++;
            continue;
        }

        // 🔹 FILTRO PARA TLDS
        if ($type === 'tlds') {
            static $tlds = null;
            if ($tlds === null) {
                $tlds = [];
                if (file_exists(BLOCKTLDS)) {
                    $tldLines = file(BLOCKTLDS, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                    foreach ($tldLines as $line) {
                        $line = trim($line);
                        if ($line && $line[0] !== '#') {
                            $tlds[] = strtolower(ltrim($line, '.'));
                        }
                    }
                }
            }
            
            $matchedTld = false;
            foreach ($tlds as $tld) {
                if (str_ends_with($domain, '.' . $tld) || $domain === $tld) {
                    $matchedTld = true;
                    break;
                }
            }
            if (!$matchedTld) continue;
        }

        // 🔹 MODO NORMAL (TCP_DENIED agrupado por dominio)
        $key = $client . '|' . $domain;

        if (!isset($incidentMap[$key])) {
            $incidentMap[$key] = [
                'ip'     => $client,
                'name'   => $userMap[$client] ?? msg('unknown'),
                'domain' => $domain,
                'hits'   => 0,
                'bytes'  => 0,
            ];
        }

        $incidentMap[$key]['hits']++;
        $incidentMap[$key]['bytes'] += $bytes;
        $totalBytes += $bytes;
    }

    pclose($handle);

    $results = array_values($incidentMap);

    usort($results, fn($a, $b) => $b['hits'] - $a['hits']);

    return [
        'type'      => $type,
        'incidents' => $results,
        'count'     => count($results)
    ];
}

/**
 * Resumen global de la red — lee LightSquid (misma fuente que la UI web)
 */
function getNetworkSummary(string $date = 'today'): array {
    // Normalizar fecha
    if ($date === 'today' || !$date) {
        $today = date('Y-m-d');
    } else {
        $cleanDate = preg_replace('/[^0-9]/', '', $date);
        if (preg_match('/^\d{8}$/', $cleanDate)) {
            $today = substr($cleanDate,0,4) . '-' . substr($cleanDate,4,2) . '-' . substr($cleanDate,6,2);
        } else {
            $today = date('Y-m-d');
        }
    }
    $dateFormatted = str_replace('-', '', $today);
    $reportBase    = LIGHTSQUID_DIR . '/' . $dateFormatted;

    $usersData = getUsers();
    $userMap   = [];
    foreach ($usersData['users'] ?? [] as $u) {
        $userMap[$u['ip']] = $u['name'];
    }

    $ipStats     = [];
    $domainStats = [];
    $totalBytes  = 0;
    $totalHits   = 0;

    $ipFiles = is_dir($reportBase) ? glob($reportBase . '/*') : [];

    foreach ($ipFiles as $ipFile) {
        if (!is_file($ipFile)) continue;
        $ip   = basename($ipFile);
        $name = $userMap[$ip] ?? msg('unknown');

        if (!isset($ipStats[$ip])) {
            $ipStats[$ip] = ['ip' => $ip, 'name' => $name, 'bytes' => 0, 'hits' => 0];
        }

        $lines = file($ipFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            if (!$line || str_starts_with($line, '#')) continue;

            if (str_starts_with($line, 'total:')) {
                $ipBytes = (int)trim(substr($line, 6));
                $ipStats[$ip]['bytes'] = $ipBytes;
                $totalBytes += $ipBytes;
                continue;
            }

            $parts = preg_split('/\s+/', $line, 4);
            if (count($parts) < 2) continue;

            $domain = $parts[0];
            $bytes  = (int)$parts[1];
            $hits   = isset($parts[2]) ? (int)$parts[2] : 1;

            $ipStats[$ip]['hits'] += $hits;

            if (!isset($domainStats[$domain])) {
                $domainStats[$domain] = ['domain' => $domain, 'bytes' => 0, 'hits' => 0];
            }
            $domainStats[$domain]['bytes'] += $bytes;
            $domainStats[$domain]['hits']  += $hits;

            $totalHits += $hits;
        }
    }

    usort($ipStats, fn($a, $b) => $b['bytes'] - $a['bytes']);
    usort($domainStats, fn($a, $b) => $b['bytes'] - $a['bytes']);

    $topUsers = array_slice(array_values($ipStats), 0, 10);
    foreach ($topUsers as &$u) $u['bytes_human'] = formatBytes($u['bytes']);

    $topDomains = array_slice(array_values($domainStats), 0, 10);
    foreach ($topDomains as &$d) $d['bytes_human'] = formatBytes($d['bytes']);

    return [
        'date'          => $today,
        'total_bytes'   => $totalBytes,
        'total_human'   => formatBytes($totalBytes),
        'total_hits'    => $totalHits,
        'unique_ips'    => count($ipStats),
        'unique_domains'=> count($domainStats),
        'top_users'     => $topUsers,
        'top_domains'   => $topDomains,
    ];
}

// ── HELPERS ──────────────────────────────────────────────────────────

function extractDomain(string $url): string {
    if (!$url || $url === '-') return '';
    
    // Manejar CONNECT (HTTPS tunnels): host:port
    if (!str_contains($url, '://') && str_contains($url, ':')) {
        return strtolower(explode(':', $url)[0]);
    }
    
    // Intentar parse_url primero
    $host = parse_url($url, PHP_URL_HOST);
    
    // Si falla, intentar limpiar URLs mal formadas (ej: https:///dominio.com)
    if (!$host) {
        // Eliminar protocolo y limpiar slashes
        $cleaned = preg_replace('#^[a-z]+:///*#i', '', $url);
        // Extraer hasta el primer slash o fin
        $host = explode('/', $cleaned)[0];
        // Eliminar puerto si existe
        $host = explode(':', $host)[0];
    }
    
    if (!$host) return '';
    
    // Quitar www.
    return strtolower(preg_replace('/^www\./', '', $host));
}

function formatBytes(int $bytes): string {
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576)    return number_format($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024)       return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}
