#!/usr/bin/perl
# squidmon-lib.pl

do './squidmon-standalone.pl';
&init_config();

1;
